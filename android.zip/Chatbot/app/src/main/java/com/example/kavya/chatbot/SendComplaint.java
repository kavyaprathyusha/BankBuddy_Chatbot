package com.example.kavya.chatbot;

      import android.content.Intent;
      import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
      import android.view.Menu;
      import android.view.MenuItem;
      import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import static android.os.StrictMode.setThreadPolicy;

public class SendComplaint extends AppCompatActivity {
    private static final String url = "jdbc:mysql://10.0.2.2:3306/Bankbuddy";
    private static final String user = "root";
    private static final String pass = "";
    String value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complaints);
        Bundle extras = getIntent().getExtras();
        if(extras!=null)
            value=extras.getString("acno");
        final EditText comp=(EditText)findViewById(R.id.comp);
        final EditText sub=(EditText)findViewById(R.id.sub);
        Button submit = (Button) findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ct = comp.getText().toString();
                String subject=sub.getText().toString();

                try {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    setThreadPolicy(policy);
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection(url, user, pass);
                    //String success = "Database connection successful\n";
                    Statement st = con.createStatement();
String sta="not";

                    // final ResultSet rs = st.executeQuery("select * from users where account_number='" + ul + "' & password='"+pl+"'");
                    Toast.makeText(getApplicationContext(), "Complaint submitted ", Toast.LENGTH_LONG).show();
                    st.executeUpdate("insert into complaints(acno,sub,ctext,status) values(' "+value+" ',' "+subject+" ',' "+ct+" ',' "+sta+" ')");



                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_logout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement

        if (id == R.id.Logout) {
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }
}

