package com.example.kavya.chatbot;

/**
 * Created by Manasa on 14-04-2017.
 */

import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import static android.os.StrictMode.setThreadPolicy;

/**
 * Created by kolli on 3/25/2017.
 */

public class FInstanceeIdService extends FirebaseInstanceIdService {
    // private static final String rt= "regtoken"; tiyyave aa error
    private static final String url = "jdbc:mysql://10.0.2.2:3306/Bankbuddy";
    private static final String user = "root";
    private static final String pass = "";
private static final String regtoken= "REG_TOKEN";
    private static  String fbid;
/*String value;
    protected void onHandleIntent(Intent intent) {
        value=(String) intent.getExtras().get("acno");
    }*/
    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String ret= FirebaseInstanceId.getInstance().getToken();
        Toast.makeText(getApplicationContext(),"opened",Toast.LENGTH_LONG).show();
                Log.d(regtoken, ret);
        fbid=ret;
        //Intent i = new Intent(getApplicationContext(), Options.class);
        //i.putExtra("acno",value);
       // i.putExtra("rettoken",ret);
        //startActivity(i);

        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            setThreadPolicy(policy);
            Class.forName("com.mysql.jdbc.Driver");
            java.sql.Connection con = DriverManager.getConnection(url, user, pass);
            //String success = "Database connection successful\n";
            Statement st = con.createStatement();
String value="1234567891012131";
            //String acno="12345";
            //final ResultSet rs = st.executeQuery("select * from users where account_number='" + ul + "' & password='"+pl+"'");

             st.executeUpdate("update users set fbid=' "+ret+" ' where acno=' "+value+" ' ");
            //Toast.makeText(getApplicationContext(), "updated firebase id", Toast.LENGTH_LONG).show();
           // Intent i = new Intent(getApplicationContext(), Options.class);
            //i.putExtra("acno",value);
            //startActivity(i);


        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        }
    }


