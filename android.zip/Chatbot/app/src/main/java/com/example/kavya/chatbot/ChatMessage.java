package com.example.kavya.chatbot;

/**
 * Created by Manasa on 19-02-2017.
 */
public class ChatMessage {
    public boolean right;
    public String message;

    public ChatMessage(boolean right, String message) {
        super();
        this.right = right;
        this.message = message;
    }
}
