<html>
<body>
<?php
$con=new mysqli('localhost','root','','Bankbuddy');
if($con->connect_error)
{
echo $con->connect_error;
}
$result=MYSQLi_query($con,"SELECT * FROM intent_count ORDER BY count DESC LIMIT 5");
if($result)
{
$row = mysqli_num_rows($result);
if($row>0){
while($p=mysqli_fetch_array($result))
{
echo $p[1]; 
echo '----';
$i=$p[1];
$lc=$p[2];
$x=mysqli_query($con,"INSERT INTO top_intents (intent,count) VALUES ('$i','$lc')");
}
}
$rs=mysqli_query($con,"select * from intent_count where count=$lc ");
while($q=mysqli_fetch_array($rs)) {
if($q[1]==$i) {} 
else {$i=$q[1]; 
	  $c=$q[2];
	echo $q[1]; echo '-----'; 
	$x=mysqli_query($con,"INSERT INTO top_intents (intent,count) VALUES ('$i','$lc')");}
}

 }




?>
</body>
</html>