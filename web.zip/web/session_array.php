<?php 
 session_start(); 
 Print_r ($_SESSION);
 ?>