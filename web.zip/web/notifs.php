<html>

<body>




<?php

$msg=$_POST['message'];
$title=$_POST['title'];
$path='https://fcm.googleapis.com/fcm/send';
$server_key='AAAAnMgAo4s:APA91bHtF6sIjBlBelu_erTX49yI87E8R-jzMCPlzadcIYZOa6ckFtmClNaXjdFW3aMjEbTa7O-6qooa2GWYUgMhAPxiakvJUdLQusfyNBjBmVmp3Q_DtA2hIOBpXfNmCLw9BU7B8MAt ';
$key= ' cBEcO3IYMw4:APA91bEp_OeWrQCdpweeLgWmhosQd-wh-ip68r72GEPY-Ig80lsWcZmKbkvj0pjI26p25X8qdKKbUNR7_4KQOPK6mrISI-SZRddSjJAO13wlqgSKcgoKzCMyFeYnO7d_RgsoD2HZx0cl';
$headers= array('Authorization:key=' .$server_key,'Content-Type:application/json');
$fields= array('to'=>$key,'notification'=>array('title'=>$title,'body'=>$msg));
$payload=json_encode($fields);
$curl_session=curl_init();
curl_setopt($curl_session, CURLOPT_URL, $path);
curl_setopt($curl_session, CURLOPT_POST,true);
curl_setopt($curl_session, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl_session, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl_session, CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($curl_session, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
curl_setopt($curl_session, CURLOPT_POSTFIELDS, $payload);
$res=curl_exec($curl_session);
curl_close($curl_session);

echo "Notification sent";	
?>
</body>
</html>