<html>
<body>
<p>Enter notification</p>
<form method="post" action="notifs.php">
Enter title:<input type='text' name='title'/></br>

Enter message:<input type='text' name='message'/>
<input type="submit" name="send" value="send"/>
</form>
</body>
</html>


 