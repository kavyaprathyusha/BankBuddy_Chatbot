<?php
session_start();
unset($_SESSION['login_user1']);
session_destroy();

header("Location: index.php");
exit;
?>